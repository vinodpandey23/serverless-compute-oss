const { v4: uuidv4 } = require('uuid');

module.exports = {
  handler: (context, event) => {
    let params = {};
    if (event.body) {
      try {
        params = JSON.parse(event.body.toString());
      } catch (e) {
        context.logger.warn(`Failed to parse event body: ${e.message}`);
      }
    }

    const defaultUser = process.env.DEFAULT_USER || 'User';
    const name = params.name || defaultUser;
    const id = uuidv4();

    const result = {
      message: `Greetings from Node.js function, ${name}!`,
      id: id
    };

    // Return plain object; Nuclio handles headers and status
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(result)
    };
  }
};
