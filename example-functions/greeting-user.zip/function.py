import json
import os

def handler(context, event):
    params = {}
    if event.body:
        if isinstance(event.body, bytes):
            try:
                params = json.loads(event.body.decode('utf-8'))
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                context.logger.error(f"Failed to decode event body: {str(e)}")
        elif isinstance(event.body, dict):
            params = event.body
        else:
            context.logger.warn(f"Unexpected event.body type: {type(event.body)}")
    
    # Use os.environ.get() with a default value to avoid KeyError
    default_user = os.environ.get("DEFAULT_USER", "User")
    result = {"message": f"Greetings from function, {params.get('name', default_user)}!"}
    return context.Response(
        body=json.dumps(result),
        headers={"Content-Type": "application/json"},
        status_code=200
    )
